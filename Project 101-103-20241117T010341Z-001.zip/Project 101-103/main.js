//https://teachablemachine.withgoogle.com/models/hNn2asgZR/

//webcam.set - It is used to make camera specifications
//webcam.attatch - It is used to attach the camera to the website
//webcam.snap - It is used to click the picture

Webcam.set({
    width:350,
    height:300,
    image_format: "png",
    png_quality: 90
})

camera = document.getElementById("camera")
Webcam.attach("#camera")

function take_snapshot(){
    Webcam.snap( function(data_uri){
    document.getElementById("result").innerHTML = "<img id='captured_image' src='"+data_uri+"'>";
    //"<img id='captured_image' src = ' " + data_uri + " '>";    
    })
}

//model integration starts here

console.log("ml5 version",ml5.version)
classifier = ml5.imageClassifier("https://teachablemachine.withgoogle.com/models/3h1Wff70A/model.json", modelloaded)

function modelloaded(){
    console.log("Model has been integrated Succesfully")
}

function check(){
   img = document.getElementById("captured_image")
   classifier.classify(img, gotresult)
}

function gotresult(error,results){
   if (error) {
    console.error(error)
   } else {
    console.log(results);
    object_name = results[0].label;
    object_confidence = results[0].confidence;
    percentage = object_confidence.toFixed(3);
    per = percentage*100;
    document.getElementById("object_name").innerHTML = object_name;
    document.getElementById("object_accuracy").innerHTML = per+"%"
   }
}